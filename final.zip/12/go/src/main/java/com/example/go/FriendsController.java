package com.example.go;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

public class FriendsController implements Initializable {

    @FXML private Label friendCodeLabel;
    @FXML private TextField friendCodeField;
    @FXML private Button sendRequestBtn;
    @FXML private ListView<String> friendsList;
    @FXML private ListView<String> pendingRequestsList;
    @FXML private Button backBtn;
    @FXML private Label statusLabel;

    private ObservableList<String> friendsObservableList;
    private ObservableList<String> pendingObservableList;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UserSession session = UserSession.getInstance();
        if (session.isLoggedIn()) {
            // Get or create friend code
            String friendCode = FriendsManager.getOrCreateFriendCode(session.getEmail());
            if (friendCode != null) {
                friendCodeLabel.setText("Your Friend Code: " + friendCode);
            }
            
            // Initialize lists
            friendsObservableList = FXCollections.observableArrayList();
            pendingObservableList = FXCollections.observableArrayList();
            friendsList.setItems(friendsObservableList);
            pendingRequestsList.setItems(pendingObservableList);
            
            // Load friends and pending requests
            loadFriends();
            loadPendingRequests();
        }
    }

    @FXML
    private void sendFriendRequest(ActionEvent event) {
        String friendCode = friendCodeField.getText().trim();
        if (friendCode.isEmpty()) {
            statusLabel.setText("Please enter a friend code");
            statusLabel.setVisible(true);
            return;
        }
        
        if (friendCode.length() != 6) {
            statusLabel.setText("Friend code must be 6 digits");
            statusLabel.setVisible(true);
            return;
        }
        
        UserSession session = UserSession.getInstance();
        if (session.isLoggedIn()) {
            String friendEmail = FriendsManager.getUserByFriendCode(friendCode);
            if (friendEmail != null) {
                boolean success = FriendsManager.sendFriendRequest(session.getEmail(), friendEmail);
                if (success) {
                    statusLabel.setText("Friend request sent successfully!");
                    statusLabel.setVisible(true);
                    friendCodeField.clear();
                } else {
                    statusLabel.setText("Failed to send friend request (already friends or request exists)");
                    statusLabel.setVisible(true);
                }
            } else {
                statusLabel.setText("Invalid friend code");
                statusLabel.setVisible(true);
            }
        }
    }

    @FXML
    private void acceptRequest(ActionEvent event) {
        String selectedRequest = pendingRequestsList.getSelectionModel().getSelectedItem();
        if (selectedRequest != null) {
            UserSession session = UserSession.getInstance();
            if (session.isLoggedIn()) {
                // Find the email of the selected friend
                String friendEmail = findEmailByName(selectedRequest);
                if (friendEmail != null) {
                    boolean success = FriendsManager.acceptFriendRequest(session.getEmail(), friendEmail);
                    if (success) {
                        statusLabel.setText("Friend request accepted!");
                        statusLabel.setVisible(true);
                        loadFriends();
                        loadPendingRequests();
                    } else {
                        statusLabel.setText("Failed to accept friend request");
                        statusLabel.setVisible(true);
                    }
                }
            }
        } else {
            statusLabel.setText("Please select a friend request to accept");
            statusLabel.setVisible(true);
        }
    }

    @FXML
    private void goBack(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/go/body.fxml"));
            Stage stage = (Stage) backBtn.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Dashboard");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadFriends() {
        UserSession session = UserSession.getInstance();
        if (session.isLoggedIn()) {
            List<String> friends = FriendsManager.getFriends(session.getEmail());
            friendsObservableList.clear();
            friendsObservableList.addAll(friends);
        }
    }

    private void loadPendingRequests() {
        UserSession session = UserSession.getInstance();
        if (session.isLoggedIn()) {
            List<String> pending = FriendsManager.getPendingRequests(session.getEmail());
            pendingObservableList.clear();
            pendingObservableList.addAll(pending);
        }
    }

    private String findEmailByName(String name) {
        // Query database to find email by name
        String query = "SELECT email FROM users WHERE name = ?";
        try (Connection conn = Db.getConnection(); PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
