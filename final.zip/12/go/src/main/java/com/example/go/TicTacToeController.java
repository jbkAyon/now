package com.example.go;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class TicTacToeController implements Initializable {

    @FXML private GridPane gameGrid;
    @FXML private Label statusLabel;
    @FXML private Label currentPlayerLabel;
    @FXML private Button resetBtn;
    @FXML private Button backBtn;
    @FXML private Button startGameBtn;
    @FXML private Button[][] gameButtons = new Button[3][3];
    
    private char currentPlayer = 'X';
    private boolean gameActive = false;
    private int moveCount = 0;
    private String player1Name = "Player X";
    private String player2Name = "Player O";
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Initialize game buttons
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                Button button = new Button();
                button.setPrefSize(80, 80);
                button.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
                final int row = i;
                final int col = j;
                button.setOnAction(e -> makeMove(row, col));
                gameButtons[i][j] = button;
                gameGrid.add(button, j, i);
            }
        }
        
        // Initialize game state
        showNameEntryDialog();
    }
    
    private void makeMove(int row, int col) {
        if (!gameActive || !gameButtons[row][col].getText().isEmpty()) {
            return;
        }
        
        // Make the move
        gameButtons[row][col].setText(String.valueOf(currentPlayer));
        gameButtons[row][col].setDisable(true);
        moveCount++;
        
        // Check for win or draw
        if (checkWin()) {
            String winnerName = (currentPlayer == 'X') ? player1Name : player2Name;
            endGame(winnerName + " (" + currentPlayer + ") wins!");
        } else if (moveCount == 9) {
            endGame("It's a draw!");
        } else {
            // Switch players
            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
            updateCurrentPlayerLabel();
        }
    }
    
    private boolean checkWin() {
        // Check rows
        for (int i = 0; i < 3; i++) {
            if (gameButtons[i][0].getText().equals(gameButtons[i][1].getText()) &&
                gameButtons[i][1].getText().equals(gameButtons[i][2].getText()) &&
                !gameButtons[i][0].getText().isEmpty()) {
                return true;
            }
        }
        
        // Check columns
        for (int j = 0; j < 3; j++) {
            if (gameButtons[0][j].getText().equals(gameButtons[1][j].getText()) &&
                gameButtons[1][j].getText().equals(gameButtons[2][j].getText()) &&
                !gameButtons[0][j].getText().isEmpty()) {
                return true;
            }
        }
        
        // Check diagonals
        if (gameButtons[0][0].getText().equals(gameButtons[1][1].getText()) &&
            gameButtons[1][1].getText().equals(gameButtons[2][2].getText()) &&
            !gameButtons[0][0].getText().isEmpty()) {
            return true;
        }
        
        if (gameButtons[0][2].getText().equals(gameButtons[1][1].getText()) &&
            gameButtons[1][1].getText().equals(gameButtons[2][0].getText()) &&
            !gameButtons[0][2].getText().isEmpty()) {
            return true;
        }
        
        return false;
    }
    
    private void endGame(String result) {
        gameActive = false;
        statusLabel.setText(result);
        currentPlayerLabel.setText("Game Over");
        
        // Disable all buttons
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                gameButtons[i][j].setDisable(true);
            }
        }
        
        // Enable start game button for new game
        if (startGameBtn != null) {
            startGameBtn.setDisable(false);
        }
    }
    
    private void updateCurrentPlayerLabel() {
        String currentPlayerName = (currentPlayer == 'X') ? player1Name : player2Name;
        currentPlayerLabel.setText("Current Player: " + currentPlayerName + " (" + currentPlayer + ")");
    }
    
    private void showNameEntryDialog() {
        // Create dialog for name entry
        Dialog<String[]> dialog = new Dialog<>();
        dialog.setTitle("Player Names");
        dialog.setHeaderText("Enter Player Names");
        
        // Create input fields
        TextField player1Field = new TextField();
        player1Field.setPromptText("Player 1 Name (X)");
        TextField player2Field = new TextField();
        player2Field.setPromptText("Player 2 Name (O)");
        
        // Set default values
        player1Field.setText("Player X");
        player2Field.setText("Player O");
        
        // Create layout
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Player 1 (X):"), 0, 0);
        grid.add(player1Field, 1, 0);
        grid.add(new Label("Player 2 (O):"), 0, 1);
        grid.add(player2Field, 1, 1);
        
        dialog.getDialogPane().setContent(grid);
        
        // Add buttons
        ButtonType startButton = new ButtonType("Start Game", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(startButton, ButtonType.CANCEL);
        
        // Set result converter
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == startButton) {
                String name1 = player1Field.getText().trim();
                String name2 = player2Field.getText().trim();
                
                if (name1.isEmpty()) name1 = "Player X";
                if (name2.isEmpty()) name2 = "Player O";
                
                return new String[]{name1, name2};
            }
            return null;
        });
        
        // Show dialog and handle result
        dialog.showAndWait().ifPresent(names -> {
            player1Name = names[0];
            player2Name = names[1];
            startGame();
        });
    }
    
    private void startGame() {
        gameActive = true;
        currentPlayer = 'X';
        moveCount = 0;
        updateCurrentPlayerLabel();
        statusLabel.setText("Game Started! " + player1Name + " goes first!");
        
        // Enable start game button
        if (startGameBtn != null) {
            startGameBtn.setDisable(true);
        }
    }
    
    @FXML
    private void resetGame(ActionEvent event) {
        showNameEntryDialog();
    }
    
    private void resetGame() {
        // Reset game state
        currentPlayer = 'X';
        gameActive = false;
        moveCount = 0;
        
        // Clear all buttons
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                gameButtons[i][j].setText("");
                gameButtons[i][j].setDisable(true);
            }
        }
        
        // Update labels
        statusLabel.setText("Click 'Start New Game' to begin");
        currentPlayerLabel.setText("Enter player names to start");
        
        // Enable start game button
        if (startGameBtn != null) {
            startGameBtn.setDisable(false);
        }
    }
    
    @FXML
    private void goBack(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/go/body.fxml"));
            Stage stage = (Stage) backBtn.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Dashboard");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}