package com.example.go;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class GameInterfaceController implements Initializable {

    @FXML private Label usernameLabel;
    @FXML private Label friendCodeLabel;
    @FXML private Label coinsLabel;
    @FXML private Button ticTacToeBtn;
    @FXML private Button hangmanBtn;
    @FXML private Button friendsBtn;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Update username display
        UserSession session = UserSession.getInstance();
        if (session.isLoggedIn()) {
            usernameLabel.setText("Welcome, " + session.getUsername());
            coinsLabel.setText("Coins: " + session.getCoins());
            
            // Get and display friend code
            String friendCode = FriendsManager.getOrCreateFriendCode(session.getEmail());
            if (friendCode != null) {
                friendCodeLabel.setText("Friend Code: " + friendCode);
            }
        }
    }

    @FXML
    private void logout(ActionEvent event) {
        UserSession.getInstance().logout();
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/go/Login.fxml"));
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Login");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void openHangman(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/go/hangman.fxml"));
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root, 800, 650));
            stage.setTitle("Hangman Game");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void openTicTacToe(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/go/tictactoe.fxml"));
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root, 400, 520));
            stage.setTitle("Tic Tac Toe");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void openFriends(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/go/friends.fxml"));
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root, 500, 400));
            stage.setTitle("Friends");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void openRockPaperScissors(ActionEvent event) {
        try {
            // Show dialog to get player names
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Rock Paper Scissors");
            dialog.setHeaderText("Enter Player Names");
            dialog.setContentText("Player 1 Name:");
            
            String player1Name = dialog.showAndWait().orElse("Player 1");
            
            dialog = new TextInputDialog();
            dialog.setTitle("Rock Paper Scissors");
            dialog.setHeaderText("Enter Player Names");
            dialog.setContentText("Player 2 Name:");
            
            String player2Name = dialog.showAndWait().orElse("Player 2");
            
            // Load RPS scene
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/go/rps.fxml"));
            Parent root = loader.load();
            
            // Set player names
            RPSController controller = loader.getController();
            controller.setPlayerNames(player1Name, player2Name);
            
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root, 900, 600));
            stage.setTitle("Rock Paper Scissors");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void showComingSoonAlert(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Coming Soon");
        alert.setHeaderText("Oops, we are still working!!!");
        alert.setContentText("This feature is under development. Please check back later!");
        
        // Add custom button
        ButtonType backButton = new ButtonType("Back");
        alert.getButtonTypes().setAll(backButton);
        
        // Show alert and handle response
        alert.showAndWait().ifPresent(response -> {
            if (response == backButton) {
                // Stay on current page (body.fxml) - no action needed
                // The alert will close automatically and return to body.fxml
            }
        });
    }
}