package com.example.go;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class HangmanController {

    @FXML private ImageView img;
    @FXML private TextField tf1, tf2, tf3, tf4, tf5, tf6, tf7, tf8;
    @FXML private TextField input;
    @FXML private Label hint;
    @FXML private Label letter_count;
    @FXML private Label statusLabel;
    @FXML private Label playerTurnLabel;
    @FXML private Button hostButton;
    @FXML private Button joinButton;
    @FXML private TextField hostPortField;
    @FXML private TextField joinHostField;
    @FXML private TextField joinPortField;

    private Image image2;
    private Image image3;
    private Image image4;
    private Image image5;
    private Image image6;
    private Image image7;

    private final String[] data = new String[]{
            "MEXICO COUNTRY",
            "HEDWIG BIRD",
            "KUAKATA BEACH",
            "CANADA COUNTRY",
            "DOCTOR PROFESSION",
            "FOOTBALL GAME",
            "TEACHER MENTOR",
            "LEOPARD ANIMAL",
            "BICYCLE TRANSPORT",
            "SALMON FISH",
            "SPARROW BIRD",
            "PARROTS BIRD",
            "EAGLE BIRD",
            "TRAIN TRANSPORT",
            "SHIP TRANSPORT",
            "ENGINEER PROFESSION",
            "BANKER PROFESSION",
            "CRICKET GAME"
    };

    private int life = 6;
    private String word;
    private String hintStr;
    
    // Multiplayer variables
    private NetworkManager.GameServer gameServer;
    private NetworkManager.GameClient gameClient;
    private boolean isHost = false;
    private boolean isMyTurn = true;
    private String currentPlayer;
    private String opponentPlayer;
    private ScheduledExecutorService messageChecker;
    private boolean gameStarted = false;

    @FXML
    private void initialize() {
        // Load images lazily and null-safe so scene doesn't crash if assets are missing
        image2 = loadImage("/com/example/go/images/2.png");
        image3 = loadImage("/com/example/go/images/3.png");
        image4 = loadImage("/com/example/go/images/4.png");
        image5 = loadImage("/com/example/go/images/5.png");
        image6 = loadImage("/com/example/go/images/6.png");
        image7 = loadImage("/com/example/go/images/7.png");
        if (image2 != null) {
            img.setImage(image2); // show initial state so image is visible immediately
        }

        // Initialize multiplayer UI
        initializeMultiplayerUI();
        
        // Initialize single player game
        initializeGame();
        
        // Set up message checker for multiplayer
        messageChecker = Executors.newScheduledThreadPool(1);
        messageChecker.scheduleAtFixedRate(this::checkForMessages, 0, 100, TimeUnit.MILLISECONDS);
    }
    
    private void initializeMultiplayerUI() {
        // Set default values for multiplayer fields
        if (hostPortField != null) hostPortField.setText("8080");
        if (joinHostField != null) joinHostField.setText("localhost");
        if (joinPortField != null) joinPortField.setText("8080");
        
        // Initialize status labels
        if (statusLabel != null) statusLabel.setText("Choose multiplayer mode or play single player");
        if (playerTurnLabel != null) playerTurnLabel.setText("");
        
        // Get current player name
        UserSession session = UserSession.getInstance();
        if (session != null && session.isLoggedIn()) {
            currentPlayer = session.getUsername();
            if (currentPlayer == null) {
                currentPlayer = "Player";
            }
        } else {
            currentPlayer = "Player";
        }
    }
    
    private void initializeGame() {
        int random = new Random().nextInt(data.length);
        String wordHint = data[random];
        String[] split = wordHint.split(" ", 2);
        word = split[0];
        hintStr = split[1];

        if (hint != null) hint.setText(hintStr);
        int letterSize = word.length();
        if (letter_count != null) letter_count.setText(letterSize + " Letters");

        if (letterSize <= 7 && tf8 != null) tf8.setVisible(false);
        if (letterSize <= 6 && tf7 != null) tf7.setVisible(false);
        if (letterSize <= 5 && tf6 != null) tf6.setVisible(false);
        if (letterSize <= 4 && tf5 != null) tf5.setVisible(false);
    }

    private Image loadImage(String path) {
        java.net.URL url = getClass().getResource(path);
        if (url == null) {
            System.err.println("Hangman image missing: " + path + " (place under src/main/resources" + path + ")");
            return null;
        }
        return new Image(url.toExternalForm());
    }

    @FXML
    private void checkInput() {
        String str = input.getText();
        if (str == null || str.isBlank()) return;
        
        // In multiplayer mode, only allow input on your turn
        if (gameStarted && !isMyTurn) {
            Platform.runLater(() -> {
                if (statusLabel != null) {
                    statusLabel.setText("Wait for " + opponentPlayer + "'s turn!");
                }
            });
            input.clear();
            return;
        }
        
        if (word.contains(str)) {
            int index = 0;
            for (int i = 0; i < word.length(); i++) {
                char c = word.charAt(i);
                if (String.valueOf(c).equalsIgnoreCase(str)) {
                    setLetter(index, Character.toString(c));
                }
                index++;
            }
            
            // Check if word is complete
            if (isWordComplete()) {
                handleGameWin();
                return;
            }
        } else {
            setImage();
            
            // Check if game is over
            if (life <= 0) {
                handleGameOver();
                return;
            }
        }
        
        // In multiplayer mode, send the guess to opponent and switch turns
        if (gameStarted) {
            sendGuessToOpponent(str);
            switchTurns();
        }
        
        input.clear();
    }
    
    @FXML
    private void hostGame() {
        try {
            String portText = hostPortField != null ? hostPortField.getText() : "8080";
            if (portText == null || portText.trim().isEmpty()) {
                portText = "8080";
            }
            
            int port = Integer.parseInt(portText);
            if (port < 1024 || port > 65535) {
                throw new IllegalArgumentException("Port must be between 1024 and 65535");
            }
            
            gameServer = new NetworkManager.GameServer(port);
            gameServer.startServer();
            isHost = true;
            gameStarted = true;
            
            Platform.runLater(() -> {
                if (statusLabel != null) {
                    statusLabel.setText("Hosting game on port " + port + ". Waiting for player...");
                }
                if (playerTurnLabel != null) {
                    playerTurnLabel.setText("Your turn: " + currentPlayer);
                }
            });
            
            // Send initial game data to client when they connect
            sendGameDataToClient();
            
        } catch (NumberFormatException e) {
            Platform.runLater(() -> {
                if (statusLabel != null) {
                    statusLabel.setText("Error: Invalid port number. Please enter a number between 1024-65535");
                }
            });
        } catch (Exception e) {
            Platform.runLater(() -> {
                if (statusLabel != null) {
                    statusLabel.setText("Error hosting game: " + e.getMessage());
                }
            });
            e.printStackTrace();
        }
    }
    
    @FXML
    private void joinGame() {
        try {
            String host = joinHostField != null ? joinHostField.getText() : "localhost";
            if (host == null || host.trim().isEmpty()) {
                host = "localhost";
            }
            
            String portText = joinPortField != null ? joinPortField.getText() : "8080";
            if (portText == null || portText.trim().isEmpty()) {
                portText = "8080";
            }
            
            int port = Integer.parseInt(portText);
            if (port < 1024 || port > 65535) {
                throw new IllegalArgumentException("Port must be between 1024 and 65535");
            }
            
            gameClient = new NetworkManager.GameClient(host, port);
            gameClient.startClient();
            isHost = false;
            gameStarted = true;
            
            Platform.runLater(() -> {
                if (statusLabel != null) {
                    statusLabel.setText("Connected to " + host + ":" + port);
                }
                if (playerTurnLabel != null) {
                    playerTurnLabel.setText("Opponent's turn");
                }
            });
            
        } catch (NumberFormatException e) {
            Platform.runLater(() -> {
                if (statusLabel != null) {
                    statusLabel.setText("Error: Invalid port number. Please enter a number between 1024-65535");
                }
            });
        } catch (Exception e) {
            Platform.runLater(() -> {
                if (statusLabel != null) {
                    statusLabel.setText("Error joining game: " + e.getMessage());
                }
            });
            e.printStackTrace();
        }
    }

    private void setLetter(int index, String str) {
        switch (index) {
            case 0 -> tf1.setText(str);
            case 1 -> tf2.setText(str);
            case 2 -> tf3.setText(str);
            case 3 -> tf4.setText(str);
            case 4 -> tf5.setText(str);
            case 5 -> tf6.setText(str);
            case 6 -> tf7.setText(str);
            case 7 -> tf8.setText(str);
        }
    }

    private void setImage() {
        if (life == 6 && image2 != null) img.setImage(image2);
        else if (life == 5 && image3 != null) img.setImage(image3);
        else if (life == 4 && image4 != null) img.setImage(image4);
        else if (life == 3 && image5 != null) img.setImage(image5);
        else if (life == 2 && image6 != null) img.setImage(image6);
        else if (life == 1 && image7 != null) img.setImage(image7);
        life--;
    }
    
    // Multiplayer helper methods
    private void checkForMessages() {
        if (!gameStarted) return;
        
        try {
            NetworkManager.GameMessage message = null;
            if (isHost && gameServer != null) {
                message = gameServer.receiveMessage();
            } else if (!isHost && gameClient != null) {
                message = gameClient.receiveMessage();
            }
            
            if (message != null) {
                Platform.runLater(() -> handleNetworkMessage(message));
            }
        } catch (Exception e) {
            // Log error but don't crash the application
            System.err.println("Error checking for messages: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void handleNetworkMessage(NetworkManager.GameMessage message) {
        if (message == null) return;
        
        try {
            switch (message.getType()) {
                case HANGMAN_GUESS:
                    String guessedLetter = message.getGuessedLetter();
                    if (guessedLetter != null && !guessedLetter.trim().isEmpty()) {
                        handleOpponentGuess(guessedLetter);
                    }
                    break;
                case HANGMAN_WORD:
                    // Update game with received word and hint
                    String receivedWord = message.getCurrentWord();
                    String receivedHint = message.getHint();
                    if (receivedWord != null && receivedHint != null) {
                        word = receivedWord;
                        hintStr = receivedHint;
                        life = message.getLives();
                        updateUIFromNetwork();
                    }
                    break;
                case HANGMAN_GAME_OVER:
                    String loserName = message.getPlayerName();
                    Platform.runLater(() -> {
                        if (statusLabel != null) {
                            statusLabel.setText("Game Over! " + (loserName != null ? loserName : "Player") + " lost!");
                        }
                    });
                    break;
                case HANGMAN_WIN:
                    String winnerName = message.getPlayerName();
                    Platform.runLater(() -> {
                        if (statusLabel != null) {
                            statusLabel.setText("Game Over! " + (winnerName != null ? winnerName : "Player") + " won!");
                        }
                    });
                    break;
                case PLAYER_JOINED:
                    String playerName = message.getPlayerName();
                    if (playerName != null) {
                        opponentPlayer = playerName;
                        Platform.runLater(() -> {
                            if (statusLabel != null) {
                                statusLabel.setText("Player " + opponentPlayer + " joined!");
                            }
                        });
                    }
                    break;
            }
        } catch (Exception e) {
            System.err.println("Error handling network message: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void handleOpponentGuess(String guessedLetter) {
        if (guessedLetter == null || guessedLetter.trim().isEmpty() || word == null) {
            return;
        }
        
        try {
            if (word.contains(guessedLetter)) {
                int index = 0;
                for (int i = 0; i < word.length(); i++) {
                    char c = word.charAt(i);
                    if (String.valueOf(c).equalsIgnoreCase(guessedLetter)) {
                        setLetter(index, Character.toString(c));
                    }
                    index++;
                }
                
                if (isWordComplete()) {
                    sendGameOverMessage(false); // Opponent won
                }
            } else {
                setImage();
                if (life <= 0) {
                    sendGameOverMessage(true); // You won
                }
            }
            
            // Switch turns after opponent's move
            switchTurns();
        } catch (Exception e) {
            System.err.println("Error handling opponent guess: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void sendGuessToOpponent(String guess) {
        if (guess == null || guess.trim().isEmpty() || currentPlayer == null) {
            return;
        }
        
        try {
            NetworkManager.GameMessage message = new NetworkManager.GameMessage(
                NetworkManager.MessageType.HANGMAN_GUESS, guess, currentPlayer);
            
            if (isHost && gameServer != null) {
                gameServer.sendMessage(message);
            } else if (!isHost && gameClient != null) {
                gameClient.sendMessage(message);
            }
        } catch (Exception e) {
            System.err.println("Error sending guess to opponent: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void sendGameDataToClient() {
        if (word == null || hintStr == null) {
            return;
        }
        
        try {
            NetworkManager.GameMessage message = new NetworkManager.GameMessage(
                NetworkManager.MessageType.HANGMAN_WORD, word, hintStr, life);
            
            if (gameServer != null) {
                gameServer.sendMessage(message);
            }
        } catch (Exception e) {
            System.err.println("Error sending game data to client: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void sendGameOverMessage(boolean won) {
        if (currentPlayer == null) {
            return;
        }
        
        try {
            NetworkManager.MessageType type = won ? NetworkManager.MessageType.HANGMAN_WIN : NetworkManager.MessageType.HANGMAN_GAME_OVER;
            NetworkManager.GameMessage message = new NetworkManager.GameMessage(type, currentPlayer);
            
            if (isHost && gameServer != null) {
                gameServer.sendMessage(message);
            } else if (!isHost && gameClient != null) {
                gameClient.sendMessage(message);
            }
        } catch (Exception e) {
            System.err.println("Error sending game over message: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void switchTurns() {
        isMyTurn = !isMyTurn;
        Platform.runLater(() -> {
            try {
                if (playerTurnLabel != null) {
                    if (isMyTurn) {
                        playerTurnLabel.setText("Your turn: " + (currentPlayer != null ? currentPlayer : "Player"));
                    } else {
                        playerTurnLabel.setText("Opponent's turn: " + (opponentPlayer != null ? opponentPlayer : "Opponent"));
                    }
                }
            } catch (Exception e) {
                System.err.println("Error switching turns: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }
    
    private boolean isWordComplete() {
        if (word == null || word.isEmpty()) {
            return false;
        }
        
        try {
            for (int i = 0; i < word.length(); i++) {
                String letter = getLetterAt(i);
                if (letter == null || letter.isEmpty()) {
                    return false;
                }
            }
            return true;
        } catch (Exception e) {
            System.err.println("Error checking if word is complete: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    private String getLetterAt(int index) {
        try {
            return switch (index) {
                case 0 -> tf1 != null ? tf1.getText() : null;
                case 1 -> tf2 != null ? tf2.getText() : null;
                case 2 -> tf3 != null ? tf3.getText() : null;
                case 3 -> tf4 != null ? tf4.getText() : null;
                case 4 -> tf5 != null ? tf5.getText() : null;
                case 5 -> tf6 != null ? tf6.getText() : null;
                case 6 -> tf7 != null ? tf7.getText() : null;
                case 7 -> tf8 != null ? tf8.getText() : null;
                default -> null;
            };
        } catch (Exception e) {
            System.err.println("Error getting letter at index " + index + ": " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    private void handleGameWin() {
        Platform.runLater(() -> {
            try {
                if (statusLabel != null) {
                    statusLabel.setText("Congratulations! You won!");
                }
            } catch (Exception e) {
                System.err.println("Error handling game win: " + e.getMessage());
                e.printStackTrace();
            }
        });
        
        if (gameStarted) {
            sendGameOverMessage(true);
        }
    }
    
    private void handleGameOver() {
        Platform.runLater(() -> {
            try {
                if (statusLabel != null) {
                    statusLabel.setText("Game Over! You lost!");
                }
            } catch (Exception e) {
                System.err.println("Error handling game over: " + e.getMessage());
                e.printStackTrace();
            }
        });
        
        if (gameStarted) {
            sendGameOverMessage(false);
        }
    }
    
    private void updateUIFromNetwork() {
        try {
            if (hint != null && hintStr != null) {
                hint.setText(hintStr);
            }
            
            if (word != null) {
                int letterSize = word.length();
                if (letter_count != null) {
                    letter_count.setText(letterSize + " Letters");
                }
            }
            
            // Update image based on lives
            if (life == 6 && image2 != null) img.setImage(image2);
            else if (life == 5 && image3 != null) img.setImage(image3);
            else if (life == 4 && image4 != null) img.setImage(image4);
            else if (life == 3 && image5 != null) img.setImage(image5);
            else if (life == 2 && image6 != null) img.setImage(image6);
            else if (life == 1 && image7 != null) img.setImage(image7);
        } catch (Exception e) {
            System.err.println("Error updating UI from network: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void backToMenu(ActionEvent event) throws IOException {
        try {
            // Clean up network resources
            if (messageChecker != null) {
                messageChecker.shutdown();
                try {
                    if (!messageChecker.awaitTermination(1, TimeUnit.SECONDS)) {
                        messageChecker.shutdownNow();
                    }
                } catch (InterruptedException e) {
                    messageChecker.shutdownNow();
                    Thread.currentThread().interrupt();
                }
            }
            
            if (gameServer != null) {
                gameServer.stopServer();
            }
            
            if (gameClient != null) {
                gameClient.disconnect();
            }
            
            Parent parent = FXMLLoader.load(getClass().getResource("/com/example/go/body.fxml"));
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setTitle("Dashboard");
            window.setScene(new Scene(parent, 600, 400));
            window.show();
        } catch (Exception e) {
            System.err.println("Error going back to menu: " + e.getMessage());
            e.printStackTrace();
            // Still try to navigate back even if cleanup fails
            try {
                Parent parent = FXMLLoader.load(getClass().getResource("/com/example/go/body.fxml"));
                Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                window.setTitle("Dashboard");
                window.setScene(new Scene(parent, 600, 400));
                window.show();
            } catch (Exception ex) {
                System.err.println("Critical error navigating back to menu: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
    }
}


