# Multiplayer Hangman Game

## Overview
This implementation adds network multiplayer functionality to the existing Hangman game, allowing two players to play together over a network connection.

## Features
- **Single Player Mode**: Play Hangman alone (original functionality)
- **Multiplayer Mode**: Two players can play together over network
- **Turn-based Gameplay**: Players take turns guessing letters
- **Real-time Synchronization**: Game state is synchronized between players
- **Error Handling**: Robust error handling for network issues

## How to Play Multiplayer

### Setting Up a Game

1. **Host a Game**:
   - One player clicks "Host Game" button
   - Enter a port number (default: 8080)
   - Wait for another player to join

2. **Join a Game**:
   - Another player clicks "Join Game" button
   - Enter the host's IP address (use "localhost" for same computer)
   - Enter the same port number as the host
   - Click "Join"

### Gameplay
- Players take turns guessing letters
- The current player's turn is displayed
- Both players see the same word and hint
- Game state (lives, guessed letters) is synchronized
- First player to complete the word or cause the other to lose wins

## Technical Implementation

### Network Architecture
- **Server-Client Model**: One player hosts (server), other joins (client)
- **TCP Socket Communication**: Reliable message delivery
- **Message Types**: 
  - `HANGMAN_GUESS`: Letter guesses
  - `HANGMAN_WORD`: Initial game data
  - `HANGMAN_GAME_OVER`: Game end notifications
  - `HANGMAN_WIN`: Win notifications

### Key Components
- **NetworkManager**: Handles network communication
- **HangmanController**: Updated with multiplayer logic
- **GameMessage**: Serializable message format
- **Thread Safety**: UI updates on JavaFX Application Thread

### Error Handling
- Network connection failures
- Invalid port numbers
- Null pointer safety
- Graceful disconnection handling

## Usage Instructions

1. **Start the Application**
2. **Login** with your account
3. **Navigate** to Hangman game
4. **Choose Mode**:
   - Play single player (original mode)
   - Host multiplayer game
   - Join multiplayer game

## Network Requirements
- Both players need network connectivity
- Firewall should allow the specified port
- For same computer: use "localhost" as host
- For different computers: use the host's IP address

## Troubleshooting

### Common Issues
1. **Connection Failed**: Check firewall settings and port availability
2. **Invalid Port**: Use ports between 1024-65535
3. **Game Not Syncing**: Check network connectivity
4. **UI Not Updating**: Restart the application

### Debug Information
- Error messages are logged to console
- Status updates shown in the game UI
- Network errors are handled gracefully

## Code Structure

### Files Modified/Added
- `HangmanController.java`: Added multiplayer functionality
- `NetworkManager.java`: Extended with Hangman message types
- `hangman.fxml`: Added multiplayer UI elements
- `styles.css`: Added multiplayer styling

### Key Methods
- `hostGame()`: Start hosting a multiplayer game
- `joinGame()`: Join an existing multiplayer game
- `checkForMessages()`: Process incoming network messages
- `sendGuessToOpponent()`: Send letter guesses to opponent
- `handleNetworkMessage()`: Handle different message types

## Future Enhancements
- Multiple game rooms
- Player chat functionality
- Score tracking
- Tournament mode
- Spectator mode

## Testing
To test the multiplayer functionality:
1. Run two instances of the application
2. Host a game on one instance
3. Join the game from the other instance
4. Play and verify synchronization works correctly
